#%% packages
from typing import OrderedDict
import torch
import torch.nn as nn

#%% sample input data of certain shape
input = torch.rand((1,3,32,32)) #format of 1 input image (batch size), 3 colour channels, width of 32, height of 32 pixels
# %%
model = nn.Sequential(OrderedDict([
    ('conv1', nn.Conv2d(3, 8, 3)), # out: (1, 8, 30, 30)   | We have selected a kernel size of 3, typically this is 3 or 5, but we can just choose and see what's up
    ('relu1', nn.ReLU()), #out: (1,8,30,30)     | Converts values between 0-1, only positives make it through.
    ('pool', nn.MaxPool2d(2, 2)), # out: (1, 8, 15, 15)
    ('conv2', nn.Conv2d(8, 16, 3)), # out: (1, 16, 13, 13)  | Here we have negative values again between -1 and 1, image size reduced by 1 pixel at each side.
    ('relu2', nn.ReLU()), # out: (1, 16, 13, 13)    | keeps values between 0 and 1
    ('pool2', nn.MaxPool2d(2, 2)), # out: (1, 16, 6, 6)    | outputs values between 0-1
    ('flatten', nn.Flatten()),  # out: (1, 16*6*6), which is: (1,576)   | Values from 0-1
    ('fc1', nn.Linear(16 * 6 * 6, 128)), # out: (1,128)     | Values from -1 to 1
    ('relu3', nn.ReLU()),   #out: (1,128)   | Values from -1 to 1 
    ('fc2', nn.Linear(128, 64)),    #out: (1,64)    | Values from -1 to 1
    ('relu4', nn.ReLU()),   #out: (1,64)    | Values from 0-1
    ('fc3', nn.Linear(64, 1)),  # out: (1,1) | Value between 0 and 1 most likely.
    ('sigmoid', nn.Sigmoid())   # out: (1,1)    | Value between 0-1     | Remember sigmoid for binary classification
]))

model(input).size()
# model(input)
# %% test the model setup

# %%
