#%%
import torch
from torchvision import transforms
from PIL import Image
import matplotlib.pyplot as plt
import numpy as np
# %% import image
img = Image.open('kiki.jpg')
img

#%% Check size of image
print(img.size) #768 x 1024

# %% compose a series of preprocessing steps
preprocess_image = transforms.Compose([
	transforms.Resize((300,300)), #scale down to 300x300 px image
	transforms.RandomRotation(50),
	transforms.CenterCrop(200),
	transforms.Grayscale(),
	transforms.RandomVerticalFlip(),
	transforms.RandomHorizontalFlip(),
	transforms.ToTensor(),
	# transforms.Normalize(mean=[0.5], std=[0.5])
])

x = preprocess_image(img) #save processed image to x
print(x.shape)  #prints ([1,200,200]) meaning 1 colour chanel, and 200 width, 200 height.


#%% Get mean and std of an image, run on a raw image that has not been normalised.
x.mean(), x.std()
# %%
