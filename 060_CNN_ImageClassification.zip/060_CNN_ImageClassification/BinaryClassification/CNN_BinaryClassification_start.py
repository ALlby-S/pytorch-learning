'''
This file will use a sample data set of images, some have concrete cracks, otheres 
have concrete in tact.
'''


#%% packages
import torch
import torchvision
import torchvision.transforms as transforms
import torch.nn as nn
import torch.nn.functional as F
import os
import matplotlib.pyplot as plt
import numpy as np

from torch.utils.data import DataLoader
from sklearn.metrics import accuracy_score
os.getcwd()

#%% setup requried transforms
transform = transforms.Compose([
    transforms.Resize(32),
    transforms.Grayscale(num_output_channels=1),
    transforms.ToTensor(),
    transforms.Normalize((0.5,),(0.5,))
])

# set batch size
batch_size = 4
#%% load data and instantiate trainloader to be used to train the CNN
trainset = torchvision.datasets.ImageFolder(root='data/train',
                                            transform=transform) #link to relative path

testset = torchvision.datasets.ImageFolder(root='data/test',
                                            transform=transform) #link to relative path


trainloader = DataLoader(trainset, batch_size=batch_size, shuffle=True)
testloader = DataLoader(testset, batch_size=batch_size, shuffle=True)


# %% visualize images, for understanding not a required step.
def imshow(img):
    img = img / 2 + 0.5     # unnormalize
    npimg = img.numpy()
    plt.imshow(np.transpose(npimg, (1, 2, 0)))
    plt.show()


# get some random training images
dataiter = iter(trainloader)
images, labels = dataiter.next()
imshow(torchvision.utils.make_grid(images, nrow=2))


# %% Neural Network setup
class ImageClassificationNet(nn.Module):
    def __init__(self) -> None:
        super().__init__()  #run init function of super class (Module from nn), aka parent class
        self.conv1 = nn.Conv2d(1,6,3) #1st convolution layer, 1 input channel, 6 output channels and kernel channel of 3.
                                      #output of conv1: Batch_size, 6, 30, 30     
                                      #remember each convolution layer reduces width and hight of images by 2.

        self.pool = nn.MaxPool2d(2,2) #pooling  layer, outputs 2x2 array
                                      #output of pool: Batch_size, 15, 15

        self.conv2 = nn.Conv2d(6,16,3) #2n convolution layer, takes 6 inputs, 16 outputs, kernel size of 3 still.
                                       #output of conv2: Batch_size, 16, 13, 13

        self.fc1 = nn.Linear(16*6*6, 128) #1st fully connected layer
                               #after pool2: output becomes: Batch_size, 16, 6, 6
                               #so for this layer we will use 16*6*6 inputs, 128 outputs
                               # 16*6*6 comes from output of pooling layer all into this fc layer. 
                               # 128 neurons are the output of this layer.

        self.fc2 = nn.Linear(128,64) #reducing dimension of neurons
        self.fc3 = nn.Linear(64,1) #reducing again from 64 to 1 output.
        
        self.sigmoid = nn.Sigmoid() #since we are using binary classification (crack/no crack) use sigmoid activation function.                         
        self.relu = nn.ReLU() #rectified linear unit

    def forward(self, x):
        x = self.conv1(x) #out: batch size, 6, 30, 30
        x = F.relu(x) #note the imported as f at the top.
        x = self.pool(x) #out: batch size, 6, 15, 15

        x = self.conv2(x) #out: batch size, 6, 13, 13
        x = F.relu(x)
        x = self.pool(x) #out: batch size, 16, 6, 6

        x = torch.flatten(x,1)# reducing 4 dimensional tensor (bs,16,6,6) to 2 dimensional with its output: batch size, 16*6*6
        x = self.fc1(x) #out: batch size, 128
        x = self.relu(x)

        x = self.fc2(x) #out: batch size, 64
        x = self.relu(x)
        x = self.fc3(x) #outputs an activated neuron, out: batch size, 1
        x = self.sigmoid(x) #set x as 1 or 0 depending on activation function parameters.

        return x

#%% init model
model = ImageClassificationNet()      


loss_fn = nn.BCELoss()

optimizer = torch.optim.SGD(model.parameters(), lr=0.001,momentum=0.8) #what is momentum? not mentionedddd


# %% training
NUM_EPOCHS = 10
for epoch in range(NUM_EPOCHS):
    for i, data in enumerate(trainloader, 0):
        inputs, labels = data
        # zero gradients
        optimizer.zero_grad()

        # forward pass
        outputs = model(inputs)

        # calc losses
        loss = loss_fn(outputs,labels.reshape(-1,1).float())

        # backward pass
        loss.backward()

        # update weights
        optimizer.step()


        if i % 100 == 0:
            print(f'Epoch {epoch}/{NUM_EPOCHS}, Step {i+1}/{len(trainloader)},'
                  f'Loss: {loss.item():.4f}')
            


# %% test
y_test = []
y_test_pred = []
for i, data in enumerate(testloader, 0):
    inputs, y_test_temp = data
    with torch.no_grad():
        y_test_hat_temp = model(inputs).round() #feed data to our model, save prediction without updating parameters
    
    y_test.extend(y_test_temp.numpy()) #saving correct answer
    y_test_pred.extend(y_test_hat_temp.numpy()) #saving predicted answer



# %%
acc = accuracy_score(y_test, y_test_pred)
print(f'Accuracy: {acc*100:.2f} %')
# %%
# We know that data is balanced, so baseline classifier has accuracy of 50 %.